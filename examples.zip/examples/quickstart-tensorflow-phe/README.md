---
tags: [quickstart, vision, fds, homomorphic-encryption, tensorflow, flower]
dataset: [CIFAR‑10]
framework: [tensorflow]
---

# Federated Learning with TensorFlow + TenSEAL in Flower  
### Cifrado homomórfico (CKKS) • Quick‑start extendido

Este proyecto parte del quick‑start oficial de Flower para TensorFlow/Keras y lo amplía con:

* **TenSEAL** para cifrado homomórfico (CKKS) en el cliente  
* Entrenamientos con **3, 10 y 20 rondas**, cuyos históricos y gráficas se incluyen  
* Scripts de visualización que generan automáticamente PNG + CSV

> Si sólo quieres lanzar la demo, bastan **tres comandos** (ver más abajo).

---

## 🗂️ Estructura del repositorio

```text
quickstart-tensorflow-he
├── pyproject.toml           # Configuración Flower (num‑server‑rounds, deps…)
├── requirements.txt         # Entorno reproducible (pip)
├── README.md                # Este documento
├── plot_history_3rounds.py  # Genera PNG + CSV de 3 rondas
├── plot_history_10rounds.py # idem para 10
├── plot_history_20rounds.py # idem para 20
├── resultados/              # PNG + CSV ya generados
│   ├── resultados_federated_HE_*.png
│   └── history_federated_HE_*.csv
└── tfexample/               # Paquete Python con la app Flower
    ├── __init__.py
    ├── client_app.py        # Cliente con TenSEAL (HE)
    ├── server_app.py        # Servidor FedAvg
    └── task.py              # Modelo, datos y utilidades
